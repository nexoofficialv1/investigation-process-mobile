import 'package:flutter/material.dart';

import '../core/app_theme.dart';
import '../models/case_file.dart';
import '../models/officer_profile.dart';
import '../services/bengali_translation_service.dart';
import '../services/case_parser_service.dart';
import '../services/local_store_service.dart';
import '../widgets/app_section_card.dart';
import '../widgets/form_helpers.dart';

class CaseParserScreen extends StatefulWidget {
  final OfficerProfile profile;
  const CaseParserScreen({super.key, required this.profile});

  @override
  State<CaseParserScreen> createState() => _CaseParserScreenState();
}

class _CaseParserScreenState extends State<CaseParserScreen> {
  final _store = LocalStoreService();
  final _parser = CaseParserService();
  final rawText = TextEditingController();

  final psCaseNo = TextEditingController();
  final caseDate = TextEditingController();
  final sections = TextEditingController();
  final po = TextEditingController();
  final dO = TextEditingController();
  final dR = TextEditingController();
  final complainant = TextEditingController();
  final victim = TextEditingController();
  final accused = TextEditingController();
  final io = TextEditingController();
  final ioMobile = TextEditingController();
  final gist = TextEditingController();
  final arrest = TextEditingController();

  List<CaseFile> _cases = [];
  CaseFile? _selectedCase;
  bool _parsed = false;

  @override
  void initState() {
    super.initState();
    _loadCases();
  }

  Future<void> _loadCases() async {
    final cases = await _store.loadCases();
    if (!mounted) return;
    setState(() => _cases = cases);
  }

  @override
  void dispose() {
    for (final c in [rawText, psCaseNo, caseDate, sections, po, dO, dR, complainant, victim, accused, io, ioMobile, gist, arrest]) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _parse() async {
    final result = _parser.parse(rawText.text);
    final translator = BengaliTranslationService.instance;

    // মামলা নম্বর, তারিখ, ধারা ও মোবাইল অপরিবর্তিত রেখে বর্ণনামূলক
    // ইংরেজি অংশগুলো বাংলায় রূপান্তর করা হয়। অনুবাদ ব্যর্থ হলে মূল লেখা থাকে।
    final translated = await Future.wait<String>([
      translator.translateToBangla(result.placeOfOccurrence),
      translator.translateToBangla(result.dateTimeOccurrence),
      translator.translateToBangla(result.dateTimeReporting),
      translator.translateToBangla(result.complainant),
      translator.translateToBangla(result.victim),
      translator.translateToBangla(result.accused),
      translator.translateToBangla(result.ioName),
      translator.translateToBangla(result.gist),
      translator.translateToBangla(result.arrest),
    ]);
    if (!mounted) return;
    setState(() {
      psCaseNo.text = result.psCaseNo;
      caseDate.text = result.caseDate;
      sections.text = result.sections;
      po.text = translated[0];
      dO.text = translated[1];
      dR.text = translated[2];
      complainant.text = translated[3];
      victim.text = translated[4];
      accused.text = translated[5];
      io.text = translated[6];
      ioMobile.text = result.ioMobile;
      gist.text = translated[7];
      arrest.text = translated[8];
      _parsed = true;
    });
    final hadEnglish = [
      result.placeOfOccurrence,
      result.dateTimeOccurrence,
      result.dateTimeReporting,
      result.complainant,
      result.victim,
      result.accused,
      result.ioName,
      result.gist,
      result.arrest,
    ].any(translator.containsEnglish);
    final stillEnglish = translated.any(translator.containsEnglish);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          hadEnglish && stillEnglish
              ? 'তথ্য সংগ্রহ হয়েছে। কিছু ইংরেজি লেখা অনুবাদ হয়নি—ইন্টারনেট সংযোগ পরীক্ষা করে অনুবাদ বোতাম চাপুন।'
              : 'তথ্য সংগ্রহ হয়েছে। সংরক্ষণের আগে যাচাই/সম্পাদনা করুন।',
        ),
      ),
    );
  }

  ParsedCaseData _currentParsed() => ParsedCaseData(
        psCaseNo: psCaseNo.text.trim(),
        caseDate: caseDate.text.trim(),
        sections: sections.text.trim(),
        placeOfOccurrence: po.text.trim(),
        dateTimeOccurrence: dO.text.trim(),
        dateTimeReporting: dR.text.trim(),
        complainant: complainant.text.trim(),
        victim: victim.text.trim(),
        accused: accused.text.trim(),
        ioName: io.text.trim(),
        ioMobile: ioMobile.text.trim(),
        gist: gist.text.trim(),
        arrest: arrest.text.trim(),
        rawText: rawText.text,
      );

  Future<void> _saveNewCase() async {
    if (!_parsed) await _parse();
    if (!mounted) return;
    final file = _currentParsed().toCaseFile(widget.profile);
    if (file.psCaseNo.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('থানা মামলা নং অনুপস্থিত। সংরক্ষণের আগে পূরণ করুন।')));
      return;
    }
    await _store.saveCase(file);
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('বিশ্লেষিত তথ্য নতুন মামলা হিসেবে সংরক্ষিত হয়েছে')));
    Navigator.pop(context);
  }

  Future<void> _updateSelectedCase() async {
    final selected = _selectedCase;
    if (selected == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('হালনাগাদের জন্য আগে বর্তমান মামলা নির্বাচন করুন।')));
      return;
    }
    if (!_parsed) await _parse();
    if (!mounted) return;
    final file = _currentParsed().toCaseFile(widget.profile, existing: selected);
    await _store.saveCase(file);
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('নির্বাচিত মামলা বিশ্লেষিত তথ্য দিয়ে হালনাগাদ হয়েছে')));
    Navigator.pop(context);
  }

  void _showCameraNote() {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('নথি স্ক্যান/ক্যামেরা থেকে লেখা শনাক্তকরণ'),
        content: const Text('এই সংস্করণে লেখা বিশ্লেষক প্রস্তুত। ক্যামেরায় অভিযোগ/এফআইআর/প্রতিবেদন স্ক্যান করে লেখা সংগ্রহের সুবিধা পরবর্তী সংস্করণে যুক্ত হবে। এখন নথির লেখা কপি/পেস্ট করে বিশ্লেষণ করুন।'),
        actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('ঠিক আছে'))],
      ),
    );
  }

  void _showUseOptions() {
    showModalBottomSheet(
      context: context,
      showDragHandle: true,
      builder: (_) => SafeArea(
        child: ListView(
          shrinkWrap: true,
          children: [
            const ListTile(title: Text('বিশ্লেষিত তথ্য দিয়ে কী করবেন?', style: TextStyle(fontWeight: FontWeight.w900))),
            ListTile(leading: const Icon(Icons.add_box), title: const Text('নতুন মামলা তৈরি করুন'), onTap: () { Navigator.pop(context); _saveNewCase(); }),
            ListTile(leading: const Icon(Icons.folder_open), title: const Text('নির্বাচিত মামলা হালনাগাদ করুন'), onTap: () { Navigator.pop(context); _updateSelectedCase(); }),
            const ListTile(leading: Icon(Icons.menu_book), title: Text('সিডি এন্ট্রি তৈরি করুন'), subtitle: Text('পরবর্তী সংস্করণে বিশ্লেষিত লেখা থেকে সিডি এন্ট্রি তৈরি হবে')),
            const ListTile(leading: Icon(Icons.description), title: Text('ফর্ম/নোটিশ তৈরি করুন'), subtitle: Text('পরবর্তী সংস্করণে নির্বাচিত মামলা/ফর্ম স্বয়ংক্রিয়ভাবে পূরণ হবে')),
            const ListTile(leading: Icon(Icons.inventory_2), title: Text('প্রমাণ/নথি হিসেবে সংরক্ষণ করুন'), subtitle: Text('পরবর্তী সংস্করণে মামলা নথি ব্যবস্থাপক যুক্ত হবে')),
          ],
        ),
      ),
    );
  }

  Future<void> _fillDemo() async {
    rawText.text = '''Ref: Kalna P.S. Case No- 558/26 Dated 08.07.26 U/S- 126(2)/115(2)/76/3(5) BNS.

P.O: Dharmadanga PS Kalna Dist Purba Bardhaman (Hatkalna GP).

D.O: On 07.07.2026 at about 13:30 Hrs.

D.R:  08.07.2026 at 13.25 hrs.

Complt: Aparna Sarkar Kharati W/o Asim Kharati of Dharmadanga PS Kalna Dist Purba Bardhaman (Mob- 81011111657).

FIR Named Accd-01 & others(1. Sargam Biswas S/o Lt. Samir Biswas of Dharmadanga PS Kalna Dist Purba Bardhaman and others)

I.O: ASI Sukanta Chakraborty (7001786060)

Gist: - On 08.07.2026 at 13:25 hrs, a written complaint was received from one Aparna Sarkar Kharati, W/o Asim Kharati of Dharmadanga, P.S. Kalna, Dist. Purba Bardhaman, to the effect that on 07.07.2026 at about 13:30 hrs, some young boys created a disturbance over an issue. Subsequently, at about 22:10 hrs, one Sargam Biswas, along with others, assaulted the complainant and her husband and also tore the wearing apparel of the complainant. On the basis of such complaint initiated this instant case. Investigation is proceeding.

Arrest: NIL.''';
    await _parse();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('মামলা তথ্য বিশ্লেষক')),
      bottomNavigationBar: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Row(
            children: [
              Expanded(child: OutlinedButton.icon(onPressed: _showUseOptions, icon: const Icon(Icons.rule), label: const Text('তথ্য ব্যবহার করুন'))),
              const SizedBox(width: 10),
              Expanded(child: FilledButton.icon(onPressed: _parse, icon: const Icon(Icons.auto_fix_high), label: const Text('বিশ্লেষণ করুন'))),
            ],
          ),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          AppSectionCard(
            title: 'মামলার লেখা পেস্ট/স্ক্যান করুন',
            subtitle: 'রেফারেন্স, ঘটনাস্থল, ঘটনার তারিখ, রিপোর্টের তারিখ, অভিযোগকারী, অভিযুক্ত, তদন্তকারী অফিসার, সংক্ষিপ্ত ঘটনা ও গ্রেপ্তার সংক্রান্ত বিন্যাস শনাক্ত করবে।',
            icon: Icons.document_scanner,
            child: Column(
              children: [
                FormHelpers.textField(controller: rawText, label: 'এখানে অভিযোগ/এফআইআর/আদেশ/প্রতিবেদনের লেখা পেস্ট করুন', maxLines: 10, autoTranslate: false),
                Row(
                  children: [
                    Expanded(child: OutlinedButton.icon(onPressed: _fillDemo, icon: const Icon(Icons.text_snippet), label: const Text('ডেমো'))),
                    const SizedBox(width: 10),
                    Expanded(child: OutlinedButton.icon(onPressed: _showCameraNote, icon: const Icon(Icons.camera_alt), label: const Text('নথি স্ক্যান করুন'))),
                  ],
                ),
              ],
            ),
          ),
          AppSectionCard(
            title: 'সংগৃহীত তথ্য যাচাই করুন',
            subtitle: 'সরাসরি সংরক্ষণ হবে না। আগে তদন্তকারী অফিসার যাচাই/সম্পাদনা করবেন, তারপর সংরক্ষণ/হালনাগাদ করবেন।',
            icon: Icons.fact_check,
            child: Column(
              children: [
                if (_cases.isNotEmpty)
                  DropdownButtonFormField<CaseFile>(
                    value: _selectedCase,
                    items: _cases.map((c) => DropdownMenuItem(value: c, child: Text(c.displayTitle, overflow: TextOverflow.ellipsis))).toList(),
                    onChanged: (v) => setState(() => _selectedCase = v),
                    decoration: const InputDecoration(labelText: 'বর্তমান মামলা হালনাগাদ (ঐচ্ছিক)', border: OutlineInputBorder()),
                  ),
                if (_cases.isNotEmpty) const SizedBox(height: 12),
                FormHelpers.textField(controller: psCaseNo, label: 'থানা মামলা নং'),
                FormHelpers.textField(controller: caseDate, label: 'মামলার তারিখ'),
                FormHelpers.textField(controller: sections, label: 'ধারা'),
                FormHelpers.textField(controller: po, label: 'ঘটনাস্থল', maxLines: 2),
                FormHelpers.textField(controller: dO, label: 'ঘটনার তারিখ ও সময়'),
                FormHelpers.textField(controller: dR, label: 'রিপোর্টের তারিখ ও সময়'),
                FormHelpers.textField(controller: complainant, label: 'অভিযোগকারী/সংবাদদাতা', maxLines: 3),
                FormHelpers.textField(controller: victim, label: 'ভিকটিম', maxLines: 2),
                FormHelpers.textField(controller: accused, label: 'এফআইআরে নামীয় অভিযুক্ত', maxLines: 4),
                Row(
                  children: [
                    Expanded(child: FormHelpers.textField(controller: io, label: 'তদন্তকারী অফিসারের নাম')),
                    const SizedBox(width: 10),
                    Expanded(child: FormHelpers.textField(controller: ioMobile, label: 'তদন্তকারী অফিসারের মোবাইল')),
                  ],
                ),
                FormHelpers.textField(controller: gist, label: 'সংক্ষিপ্ত ঘটনা', maxLines: 6),
                FormHelpers.textField(controller: arrest, label: 'গ্রেপ্তারের অবস্থা'),
                const SizedBox(height: 8),
                const Text('সংরক্ষণের পরে এই তথ্য মামলা এন্ট্রি, সিডি-১, ফর্ম, বিবৃতি, চূড়ান্ত সিডি ও আইএফ-৫-এ স্বয়ংক্রিয়ভাবে বসবে।', style: TextStyle(color: AppTheme.deepGreen, fontWeight: FontWeight.w700)),
              ],
            ),
          ),
          const SizedBox(height: 90),
        ],
      ),
    );
  }
}
