import 'dart:io';

import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import 'package:printing/printing.dart';
import 'package:share_plus/share_plus.dart';

import '../core/app_theme.dart';
import '../models/officer_profile.dart';
import '../models/ud_case.dart';
import '../services/doc_export_service.dart';
import '../services/bengali_translation_service.dart';
import '../services/local_store_service.dart';
import '../services/pdf_service.dart';
import '../widgets/form_helpers.dart';

class UdCaseScreen extends StatefulWidget {
  final OfficerProfile profile;
  const UdCaseScreen({super.key, required this.profile});

  @override
  State<UdCaseScreen> createState() => _UdCaseScreenState();
}

class _UdCaseScreenState extends State<UdCaseScreen> {
  final _store = LocalStoreService();
  final _pdf = PdfService();
  final _doc = DocExportService();
  final Map<String, TextEditingController> _c = {};
  List<UdCase> _saved = [];
  UdCase _ud = UdCase.empty();
  String _injuryPart = 'injuryHead';
  String _dischargePart = 'nostrils';

  static const Map<String, String> _injuryOptions = {
    'injuryHead': 'মাথা',
    'injuryFace': 'মুখ',
    'injuryNeck': 'ঘাড়',
    'injuryChest': 'বুক',
    'injuryStomach': 'পেট',
    'injuryShoulder': 'কাঁধ',
    'injuryRightHand': 'ডান হাত',
    'injuryLeftHand': 'বাঁ হাত',
    'injuryRightLeg': 'ডান পা',
    'injuryLeftLeg': 'বাঁ পা',
    'injuryPrivateParts': 'গোপনাঙ্গ',
    'injuryBack': 'পিঠ',
    'injuryOther': 'অন্যান্য আঘাত',
  };

  static const Map<String, String> _dischargeOptions = {
    'nostrils': 'নাসারন্ধ্র',
    'earsEyes': 'কান / চোখ',
    'mouth': 'মুখ',
    'penisVagina': 'পুরুষাঙ্গ / যোনি',
    'anus': 'মলদ্বার',
  };

  final List<_F> _fields = const [
    _F('district', 'জেলা'),
    _F('policeStation', 'থানা'),
    _F('udNo', 'এফআইআর/ইউডি নং'),
    _F('gdeNo', 'জিডিই নং ও তারিখ'),
    _F('dateTime', 'তারিখ ও সময়'),
    _F('distanceFromPs', 'থানা থেকে দূরত্ব'),
    _F('directionFromPs', 'থানা থেকে দিক'),
    _F('placeFound', 'মৃতদেহ পাওয়ার স্থান'),
    _F('longitude', 'দ্রাঘিমাংশ'),
    _F('latitude', 'অক্ষাংশ'),
    _F('deadBodyFoundDate', 'মৃতদেহ পাওয়া/সন্ধান পাওয়ার তারিখ'),
    _F('deadBodyFoundTime', 'মৃতদেহ পাওয়া/সন্ধান পাওয়ার সময়'),
    _F('informantName', 'তথ্যদাতার নাম'),
    _F('informantAge', 'তথ্যদাতার বয়স'),
    _F('informantSex', 'তথ্যদাতার লিঙ্গ'),
    _F('informantAddress', 'তথ্যদাতার ঠিকানা', lines: 2),
    _F('identifiedByName', 'মৃতদেহ শনাক্তকারীর নাম'),
    _F('identifiedByAge', 'শনাক্তকারীর বয়স'),
    _F('identifiedBySex', 'শনাক্তকারীর লিঙ্গ'),
    _F('identifiedByRelation', 'সম্পর্ক (যদি থাকে)'),
    _F('identifiedByAddress', 'শনাক্তকারীর ঠিকানা', lines: 2),
    _F('deceasedName', 'মৃত ব্যক্তির নাম'),
    _F('deceasedSex', 'লিঙ্গ: পুরুষ/মহিলা'),
    _F('deceasedAge', 'আনুমানিক বয়স'),
    _F('deceasedAddress', 'মৃত ব্যক্তির ঠিকানা', lines: 2),
    _F('bodyPosition', 'পোস্টমর্টেম স্টেইনিংসহ মৃতদেহের অবস্থান', lines: 3),
    _F('build', 'দেহের গঠন'),
    _F('height', 'উচ্চতা'),
    _F('rigorMortis', 'রিগর মর্টিস'),
    _F('complexion', 'গায়ের রং'),
    _F('deformities', 'বিকৃতি (যদি থাকে)'),
    _F('religionRaceCommunity', 'ধর্ম/জাতি/সম্প্রদায়'),
    _F('teeth', 'শনাক্তকরণ চিহ্ন: দাঁত'),
    _F('eyes', 'চোখ'),
    _F('laceDerma', 'ত্বকের বিশেষ চিহ্ন'),
    _F('mole', 'তিল'),
    _F('tattoo', 'উল্কি'),
    _F('dress', 'পোশাক/পরিধেয় বস্ত্র', lines: 2),
    _F('otherFeatures', 'অন্যান্য বৈশিষ্ট্য (যদি থাকে)', lines: 2),
    _F('weaponOpinion', 'অস্ত্রের প্রকৃতি/আঘাতের পদ্ধতি সম্পর্কে মতামত', lines: 3),
    _F('ligatureDescription', 'গলার দাগ / দড়ি / গিঁটের বিবরণ', lines: 3),
    _F('foreignMaterial', 'মৃতদেহে পাওয়া বহিরাগত পদার্থ', lines: 3),
    _F('poDescription', 'ঘটনাস্থলের বিবরণ', lines: 3),
    _F('articlesAtPo', 'ঘটনাস্থলে পাওয়া অস্ত্র/অলংকার/অন্যান্য বস্তু', lines: 3),
    _F('probableCauseOfDeath', 'মৃত্যুর সম্ভাব্য কারণ', lines: 2),
    _F('remarks', 'মন্তব্য', lines: 3),
    _F('witness1NameAddress', 'সাক্ষী (১)-এর নাম/ঠিকানা', lines: 2),
    _F('witness2NameAddress', 'সাক্ষী (২)-এর নাম/ঠিকানা', lines: 2),
    _F('briefFacts', 'সংক্ষিপ্ত ঘটনা', lines: 5),
  ];

  @override
  void initState() {
    super.initState();
    _ud = UdCase.empty(ps: widget.profile.policeStation, district: widget.profile.district);
    _initControllers();
    _loadSaved();
  }

  void _initControllers() {
    final map = _ud.toJson();
    for (final f in _fields) {
      _c[f.key] = TextEditingController(text: (map[f.key] ?? '').toString());
    }
    for (final key in [..._injuryOptions.keys, ..._dischargeOptions.keys]) {
      _c[key] = TextEditingController(text: (map[key] ?? '').toString());
    }
  }

  Future<void> _loadSaved() async {
    final list = await _store.loadUdCases();
    if (!mounted) return;
    setState(() => _saved = list);
  }

  UdCase _collect() {
    final values = {
      for (final f in _fields) f.key: _c[f.key]!.text.trim(),
      for (final key in [..._injuryOptions.keys, ..._dischargeOptions.keys]) key: _c[key]!.text.trim(),
    };
    return _ud.copyWith(values);
  }

  Iterable<TextEditingController> get _translatableControllers {
    const protectedKeys = <String>{
      'udNo', 'gdeNo', 'dateTime', 'longitude', 'latitude',
      'deadBodyFoundDate', 'deadBodyFoundTime', 'informantAge',
      'identifiedByAge', 'deceasedAge', 'height',
    };
    return _c.entries.where((entry) => !protectedKeys.contains(entry.key)).map((entry) => entry.value);
  }

  Future<void> _save() async {
    await BengaliTranslationService.instance.translateControllers(_translatableControllers);
    if (!mounted) return;
    _ud = _collect();
    await _store.saveUdCase(_ud);
    await _loadSaved();
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('ইউডি সুরতহালের খসড়া সংরক্ষিত হয়েছে।')));
  }

  Future<void> _previewPdf() async {
    await BengaliTranslationService.instance.translateControllers(_translatableControllers);
    if (!mounted) return;
    _ud = _collect();
    final bytes = await _pdf.buildUdInquestPdf(officer: widget.profile, ud: _ud);
    await Printing.layoutPdf(onLayout: (_) async => bytes);
  }

  Future<void> _exportPdf() async {
    await BengaliTranslationService.instance.translateControllers(_translatableControllers);
    if (!mounted) return;
    _ud = _collect();
    final bytes = await _pdf.buildUdInquestPdf(officer: widget.profile, ud: _ud);
    await Printing.sharePdf(bytes: bytes, filename: 'UD_Inquest_${_ud.udNo.replaceAll('/', '_')}.pdf');
  }

  Future<void> _exportDoc() async {
    await BengaliTranslationService.instance.translateControllers(_translatableControllers);
    if (!mounted) return;
    _ud = _collect();
    final bytes = await _doc.buildUdInquestDoc(officer: widget.profile, ud: _ud);
    final dir = await getTemporaryDirectory();
    final path = '${dir.path}/UD_Inquest_${_ud.udNo.replaceAll('/', '_')}.doc';
    final file = File(path);
    await file.writeAsBytes(bytes, flush: true);
    await Share.shareXFiles([XFile(path)], text: 'ইউডি সুরতহাল ডক');
  }

  void _loadUd(UdCase ud) {
    setState(() {
      _ud = ud;
      final map = ud.toJson();
      for (final f in _fields) {
        _c[f.key]!.text = (map[f.key] ?? '').toString();
      }
      for (final key in [..._injuryOptions.keys, ..._dischargeOptions.keys]) {
        _c[key]!.text = (map[key] ?? '').toString();
      }
    });
  }

  void _newUd() {
    setState(() {
      _ud = UdCase.empty(ps: widget.profile.policeStation, district: widget.profile.district);
      final map = _ud.toJson();
      for (final f in _fields) {
        _c[f.key]!.text = (map[f.key] ?? '').toString();
      }
      for (final key in [..._injuryOptions.keys, ..._dischargeOptions.keys]) {
        _c[key]!.text = (map[key] ?? '').toString();
      }
    });
  }

  @override
  void dispose() {
    for (final c in _c.values) {
      c.dispose();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.cream,
      appBar: AppBar(
        title: const Text('ইউডি মামলা / সুরতহাল'),
        actions: [IconButton(onPressed: _newUd, icon: const Icon(Icons.add))],
      ),
      body: ListView(
        padding: const EdgeInsets.all(14),
        children: [
          if (_saved.isNotEmpty) _savedList(),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('সুরতহাল ফর্ম — বিএনএসএস-এর ১৯৪/১৯৬ ধারা', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
                  const SizedBox(height: 6),
                  const Text('প্রদত্ত সরকারি ফর্ম অনুযায়ী প্রতিটি ঘরের তথ্য লিখুন। এক্সপোর্টের আগে প্রিভিউ দেখে নিন। ইংরেজিতে লিখলে লেখা স্বয়ংক্রিয়ভাবে বাংলায় অনুবাদ হবে।', style: TextStyle(fontWeight: FontWeight.w600)),
                  const SizedBox(height: 14),
                  ..._fields.map((f) {
                    final field = Padding(
                      padding: const EdgeInsets.only(bottom: 10),
                      child: BanglaTextField(
                        controller: _c[f.key]!,
                        label: f.label,
                        maxLines: f.lines > 1 ? f.lines + 2 : 1,
                        autoTranslate: !<String>{'dateTime', 'udNo', 'gdeNo', 'longitude', 'latitude', 'deadBodyFoundDate', 'deadBodyFoundTime', 'informantAge', 'identifiedByAge', 'deceasedAge', 'height'}.contains(f.key),
                        decoration: InputDecoration(labelText: f.label, border: const OutlineInputBorder(), filled: true, fillColor: Colors.white),
                      ),
                    );
                    if (f.key == 'otherFeatures') {
                      return Column(children: [field, _injuryDropdownCard(), _dischargeDropdownCard()]);
                    }
                    return field;
                  }),
                ],
              ),
            ),
          ),
          const SizedBox(height: 10),
          Wrap(
            spacing: 10,
            runSpacing: 10,
            children: [
              ElevatedButton.icon(onPressed: _save, icon: const Icon(Icons.save), label: const Text('খসড়া সংরক্ষণ')),
              OutlinedButton.icon(onPressed: _previewPdf, icon: const Icon(Icons.visibility), label: const Text('প্রিভিউ')),
              ElevatedButton.icon(onPressed: _exportPdf, icon: const Icon(Icons.picture_as_pdf), label: const Text('পিডিএফ এক্সপোর্ট')),
              ElevatedButton.icon(onPressed: _exportDoc, icon: const Icon(Icons.description), label: const Text('ডক এক্সপোর্ট')),
            ],
          ),
          const SizedBox(height: 80),
        ],
      ),
    );
  }


  Widget _injuryDropdownCard() {
    return Card(
      color: Colors.orange.shade50,
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('১০। মৃতদেহে পাওয়া বাহ্যিক আঘাতের বিবরণ', style: TextStyle(fontWeight: FontWeight.w900)),
            const SizedBox(height: 8),
            DropdownButtonFormField<String>(
              value: _injuryPart,
              decoration: const InputDecoration(labelText: 'শরীরের অংশ নির্বাচন করুন', border: OutlineInputBorder(), filled: true, fillColor: Colors.white),
              items: _injuryOptions.entries.map((e) => DropdownMenuItem(value: e.key, child: Text(e.value))).toList(),
              onChanged: (v) => setState(() => _injuryPart = v ?? _injuryPart),
            ),
            const SizedBox(height: 8),
            BanglaTextField(
              controller: _c[_injuryPart]!,
              label: '${_injuryOptions[_injuryPart]}-এর আঘাতের বিবরণ',
              maxLines: 5,
              decoration: InputDecoration(
                labelText: '${_injuryOptions[_injuryPart]}-এর আঘাতের বিবরণ',
                helperText: 'তালিকা থেকে শরীরের অংশ নির্বাচন করে আঘাতের বিবরণ লিখুন। এটি সরকারি ১০ নং ক্রমিকে এক্সপোর্ট হবে।',
                border: const OutlineInputBorder(),
                filled: true,
                fillColor: Colors.white,
              ),
            ),
            const SizedBox(height: 8),
            _summaryList(_injuryOptions),
          ],
        ),
      ),
    );
  }

  Widget _dischargeDropdownCard() {
    return Card(
      color: Colors.blueGrey.shade50,
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('১১। নির্গমন/স্রাবের বিবরণ', style: TextStyle(fontWeight: FontWeight.w900)),
            const SizedBox(height: 8),
            DropdownButtonFormField<String>(
              value: _dischargePart,
              decoration: const InputDecoration(labelText: 'অঙ্গ/স্থান নির্বাচন করুন', border: OutlineInputBorder(), filled: true, fillColor: Colors.white),
              items: _dischargeOptions.entries.map((e) => DropdownMenuItem(value: e.key, child: Text(e.value))).toList(),
              onChanged: (v) => setState(() => _dischargePart = v ?? _dischargePart),
            ),
            const SizedBox(height: 8),
            BanglaTextField(
              controller: _c[_dischargePart]!,
              label: '${_dischargeOptions[_dischargePart]}-এর বিবরণ',
              maxLines: 4,
              decoration: InputDecoration(
                labelText: '${_dischargeOptions[_dischargePart]}-এর বিবরণ',
                helperText: 'তালিকা থেকে অঙ্গ/স্থান নির্বাচন করে নির্গমন/স্রাবের বিবরণ লিখুন। এটি সরকারি ১১ নং ক্রমিকে এক্সপোর্ট হবে।',
                border: const OutlineInputBorder(),
                filled: true,
                fillColor: Colors.white,
              ),
            ),
            const SizedBox(height: 8),
            _summaryList(_dischargeOptions),
          ],
        ),
      ),
    );
  }

  Widget _summaryList(Map<String, String> options) {
    final filled = options.entries.where((e) => (_c[e.key]?.text.trim().isNotEmpty ?? false)).toList();
    if (filled.isEmpty) {
      return const Text('এখনও কোনো এন্ট্রি যোগ করা হয়নি।', style: TextStyle(fontStyle: FontStyle.italic));
    }
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: filled.map((e) => Padding(
        padding: const EdgeInsets.only(bottom: 4),
        child: Text('• ${e.value}: ${_c[e.key]!.text.trim()}', maxLines: 2, overflow: TextOverflow.ellipsis),
      )).toList(),
    );
  }

  Widget _savedList() {
    return Card(
      child: ExpansionTile(
        leading: const Icon(Icons.history),
        title: const Text('সংরক্ষিত ইউডি খসড়া', style: TextStyle(fontWeight: FontWeight.w900)),
        children: _saved.map((ud) => ListTile(
              title: Text(ud.displayTitle),
              subtitle: Text('মৃত ব্যক্তি: ${ud.deceasedName}\nস্থান: ${ud.placeFound}', maxLines: 2),
              isThreeLine: true,
              onTap: () => _loadUd(ud),
            )).toList(),
      ),
    );
  }
}

class _F {
  final String key;
  final String label;
  final int lines;
  const _F(this.key, this.label, {this.lines = 1});
}
