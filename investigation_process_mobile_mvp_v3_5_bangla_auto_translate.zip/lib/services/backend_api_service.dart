import 'dart:convert';

import 'package:http/http.dart' as http;

import '../models/backend_config.dart';
import '../models/case_file.dart';
import '../models/officer_profile.dart';

class BackendApiService {
  Future<String> testConnection(BackendConfig config) async {
    if (!config.isCustomServer) {
      return config.mode == 'offline' ? 'অফলাইন মোড নির্বাচিত হয়েছে' : 'সুপাবেস মোড পরে কনফিগার করা হবে';
    }
    final base = config.apiBaseUrl.trim().replaceAll(RegExp(r'/+$'), '');
    if (base.isEmpty) return 'এপিআই মূল ইউআরএল দেওয়া হয়নি';
    try {
      final res = await http
          .get(Uri.parse('$base/health'), headers: _headers(config))
          .timeout(const Duration(seconds: 10));
      if (res.statusCode >= 200 && res.statusCode < 300) {
        return 'সংযোগ সফল: ${res.body}';
      }
      return 'সার্ভারের উত্তর ${res.statusCode}: ${res.body}';
    } catch (e) {
      return 'সংযোগ ব্যর্থ: $e';
    }
  }

  Future<String> syncCases({
    required BackendConfig config,
    required OfficerProfile profile,
    required List<CaseFile> cases,
  }) async {
    if (!config.isCustomServer || !config.syncEnabled) return 'সিঙ্ক বন্ধ রয়েছে';
    final base = config.apiBaseUrl.trim().replaceAll(RegExp(r'/+$'), '');
    if (base.isEmpty) return 'এপিআই মূল ইউআরএল দেওয়া হয়নি';
    try {
      final payload = {
        'officer': profile.toJson(),
        'cases': cases.map((e) => e.toJson()).toList(),
      };
      final res = await http
          .post(Uri.parse('$base/api/sync/cases'), headers: _headers(config), body: jsonEncode(payload))
          .timeout(const Duration(seconds: 20));
      if (res.statusCode >= 200 && res.statusCode < 300) return '${cases.length}টি মামলা সিঙ্ক হয়েছে';
      return 'সিঙ্ক ব্যর্থ ${res.statusCode}: ${res.body}';
    } catch (e) {
      return 'সিঙ্ক ব্যর্থ: $e';
    }
  }

  Map<String, String> _headers(BackendConfig config) => {
        'Content-Type': 'application/json',
        if (config.apiToken.trim().isNotEmpty) 'Authorization': 'Bearer ${config.apiToken.trim()}',
      };
}
