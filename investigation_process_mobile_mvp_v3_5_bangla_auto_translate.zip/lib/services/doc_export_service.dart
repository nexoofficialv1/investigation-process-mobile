import 'dart:convert';
import 'dart:typed_data';

import '../models/case_file.dart';
import '../models/cd_entry.dart';
import '../models/form_notice.dart';
import '../models/officer_profile.dart';
import '../models/sketch_map.dart';
import '../models/statement_entry.dart';
import '../models/ud_case.dart';

class DocExportService {
  Uint8List _docBytes(String html) => Uint8List.fromList(utf8.encode(html));

  String _e(String value) =>
      const HtmlEscape().convert(value).replaceAll('\n', '<br/>');

  String _page(String title, String body) => '''
<html>
<head>
<meta charset="utf-8">
<title>${_e(title)}</title>
<style>
  @page { size: A4; margin: 18mm 14mm 18mm 14mm; }
  body { font-family: "Noto Sans Bengali", "Nirmala UI", "SolaimanLipi", sans-serif; font-size: 12pt; color: #000; }
  table { border-collapse: collapse; width: 100%; }
  td, th { border: 1px solid #555; padding: 4px; vertical-align: top; }
  .center { text-align: center; }
  .right { text-align: right; }
  .bold { font-weight: bold; }
  .small { font-size: 10.5pt; }
  .cd td { font-size: 10.5pt; }
  .no-border td, .no-border th { border: none; }
  .justify { text-align: justify; }
  .page-break { page-break-before: always; }
</style>
</head>
<body>$body</body>
</html>
''';

  Future<Uint8List> buildCaseDiaryDoc({
    required OfficerProfile officer,
    required CaseFile caseFile,
    required CdEntry cd,
  }) async {
    final lines = cd.tableLines.isNotEmpty
        ? cd.tableLines
        : [
            CdTableLine(
              noAndHour: '১\n${cd.startTime}',
              placeOfEntry: cd.placeOfEntry,
              synopsis: cd.cdNumber == 1
                  ? 'এফআইআরের অনুলিপি গ্রহণ\n+\nসংক্ষিপ্ত ঘটনা'
                  : 'পরবর্তী তদন্ত',
              proceedings: cd.body,
            ),
          ];
    final noHour = lines.map((e) => _e(e.noAndHour)).join('<br/><br/><br/>');
    final places =
        lines.map((e) => _e(e.placeOfEntry)).join('<br/><br/><br/>');
    final synopsis =
        lines.map((e) => _e(e.synopsis)).join('<br/><br/><br/>');
    final proceedings =
        lines.map((e) => '<p>${_e(e.proceedings)}</p>').join('');
    final year = DateTime.now().year;
    final ps = officer.policeStation
        .replaceAll('Police Station', 'থানা')
        .replaceAll(' PS', ' থানা')
        .trim();
    final html = '''
<div class="bold">
  <span>পশ্চিমবঙ্গ ফর্ম নং ৫৩৬৩</span><span style="float:right">সাল $year</span>
</div>
<div class="center bold">বিএনএসএস-এর ১৯২ ধারার অধীন কেস ডায়েরি</div>
<div class="center bold">(পি.আর.বি. ফর্ম নং ৪৩ — বিধি ২২৯ দ্রষ্টব্য)</div>
<table class="no-border small">
<tr><td class="bold">থানা: $ps</td><td class="bold right">জেলা: ${_e(officer.district)}</td></tr>
<tr><td class="bold">প্রথম তথ্য/মামলা নং: ${_e(caseFile.psCaseNo)}</td><td class="bold">তারিখ: ${_e(caseFile.caseDate)} &nbsp;&nbsp;&nbsp; ধারা: ${_e(caseFile.sections)}</td></tr>
<tr><td colspan="2" class="bold">অভিযোগকারীর নাম: ${_e(caseFile.complainantName)}</td></tr>
<tr><td class="bold">কেস ডায়েরি নং: ${cd.cdNumber}</td><td class="bold">তারিখ: ${_e(cd.cdDate)}</td></tr>
</table>
<table class="cd">
<tr><td class="center">গ্রেপ্তার করে আদালতে প্রেরিত</td><td class="center">গ্রেপ্তার করে জামিনে মুক্ত</td><td class="center" colspan="2">পলাতক/ধরা যায়নি</td></tr>
<tr><td colspan="4" class="bold">তদন্তের বিবরণ</td></tr>
<tr><td class="center" style="width:10%">এন্ট্রি নং<br/>ও সময়</td><td class="center" style="width:10%">এন্ট্রির<br/>স্থান</td><td class="center" style="width:13%">এন্ট্রির<br/>সারাংশ</td><td style="width:67%"></td></tr>
<tr><td class="center">$noHour</td><td class="center">$places</td><td class="center">$synopsis</td><td class="justify">$proceedings</td></tr>
</table>
<div class="right" style="margin-top:18px;margin-right:70px">পেশ করা হলো<br/><br/><br/>(${_e(officer.name)})<br/>${_e(officer.rank)}<br/>$ps</div>
''';
    return _docBytes(_page('কেস ডায়েরি-${cd.cdNumber}', html));
  }

  Future<Uint8List> buildStatementDoc({
    required OfficerProfile officer,
    required CaseFile caseFile,
    required StatementEntry statement,
  }) async {
    final html = '''
<div class="center bold">বিএনএসএস-এর ১৮০ ধারায় লিপিবদ্ধ সাক্ষীর বিবৃতি</div><br/>
<p>মামলার রেফারেন্স: ${_e(officer.policeStation)} থানা মামলা নং ${_e(caseFile.psCaseNo)}, তারিখ ${_e(caseFile.caseDate)}, ধারা ${_e(caseFile.sections)}</p>
<p>সাক্ষীর নাম: ${_e(statement.witnessName)}<br/>সাক্ষীর বিবরণ: ${_e(statement.witnessDetails)}<br/>বিবৃতির ধরন: ${_e(statement.statementType)}</p>
<p class="justify">${_e(statement.body)}</p>
<table class="no-border" style="margin-top:40px"><tr><td>সাক্ষীর স্বাক্ষর/বাম হাতের ছাপ/ডান হাতের ছাপ</td><td class="right">লিপিবদ্ধ করেছেন<br/><br/>${_e(officer.rank)} ${_e(officer.name)}<br/>${_e(officer.policeStation)}</td></tr></table>
''';
    return _docBytes(_page('সাক্ষীর বিবৃতি', html));
  }

  Future<Uint8List> buildFormNoticeDoc({
    required OfficerProfile officer,
    required CaseFile caseFile,
    required FormNotice form,
  }) async {
    final html = '''
<div class="center bold">${_e(form.title)}</div><br/>
<p class="small">রেফারেন্স: ${_e(officer.policeStation)} থানা মামলা নং ${_e(caseFile.psCaseNo)}, তারিখ ${_e(caseFile.caseDate)}, ধারা ${_e(caseFile.sections)}</p>
<p class="justify">${_e(form.body)}</p>
<div class="right" style="margin-top:36px">পেশ করা হলো,<br/><br/>${_e(officer.name)}<br/>${_e(officer.rank)}<br/>${_e(officer.policeStation)}, ${_e(officer.district)}</div>
''';
    return _docBytes(_page(form.title, html));
  }

  Future<Uint8List> buildGeneralReportDoc({
    required OfficerProfile officer,
    required FormNotice form,
  }) async {
    final html = '''
<div class="center bold">${_e(form.title)}</div><br/>
<p class="justify">${_e(form.body)}</p>
<div class="right" style="margin-top:36px">${_e(officer.rank)} ${_e(officer.name)}<br/>${_e(officer.policeStation)}<br/>জেলা: ${_e(officer.district)}</div>
''';
    return _docBytes(_page(form.title, html));
  }

  Future<Uint8List> buildSketchMapDoc({
    required OfficerProfile officer,
    required CaseFile caseFile,
    required SketchMapEntry sketch,
  }) async {
    final rows = sketch.objects
        .map(
          (o) => '<tr><td>${_e(o.marker)}</td><td>${_e(o.label)}</td><td>${_e(o.direction)}</td><td>${_e(o.indexDescription)}</td></tr>',
        )
        .join();
    final html = '''
<div class="center bold">সূচিসহ ঘটনাস্থলের খসড়া নকশা</div>
<p>মামলার রেফারেন্স: ${_e(officer.policeStation)} থানা মামলা নং ${_e(caseFile.psCaseNo)}, তারিখ ${_e(caseFile.caseDate)}, ধারা ${_e(caseFile.sections)}</p>
<p>ঘটনাস্থল: ${_e(sketch.poDescription)}</p>
<table><tr><th>চিহ্ন</th><th>নাম</th><th>দিক</th><th>সূচির বিবরণ</th></tr>$rows</table>
<p>উত্তর: ${_e(sketch.north)}<br/>দক্ষিণ: ${_e(sketch.south)}<br/>পূর্ব: ${_e(sketch.east)}<br/>পশ্চিম: ${_e(sketch.west)}</p>
<div class="right" style="margin-top:36px">প্রস্তুত করেছেন<br/><br/>(${_e(officer.name)})<br/>${_e(officer.rank)}<br/>${_e(officer.policeStation)}</div>
''';
    return _docBytes(_page('খসড়া নকশা', html));
  }
}

extension UdInquestDocExport on DocExportService {
  Future<Uint8List> buildUdInquestDoc({
    required OfficerProfile officer,
    required UdCase ud,
  }) async {
    String e(String v) =>
        const HtmlEscape().convert(v).replaceAll('\n', '<br/>');
    String row(String label, String value) =>
        '<p>$label <span style="border-bottom:1px dotted #777;display:inline-block;min-width:480px">${e(value)}</span></p>';
    final html = _page('ইউডি সুরতহাল প্রতিবেদন', '''
<div class="center bold">সুরতহাল প্রতিবেদন</div>
<div class="center bold">বিএনএসএস-এর ১৯৪/১৯৬ ধারা</div>
${row('১। জেলা:', ud.district)}
${row('থানা:', ud.policeStation)}
${row('তারিখ ও সময়:', ud.dateTime)}
${row('২। এফআইআর/ইউডি নং:', ud.udNo)}
${row('জিডিই নং ও তারিখ:', ud.gdeNo)}
${row('৩(ক)। থানা থেকে দূরত্ব:', ud.distanceFromPs)}
${row('(খ) থানা থেকে দিক:', ud.directionFromPs)}
${row('(গ) মৃতদেহ পাওয়ার স্থান:', ud.placeFound)}
${row('দ্রাঘিমাংশ:', ud.longitude)} ${row('অক্ষাংশ:', ud.latitude)}
${row('(ঘ) মৃতদেহ পাওয়া/সন্ধান পাওয়ার তারিখ:', ud.deadBodyFoundDate)} ${row('সময়:', ud.deadBodyFoundTime)}
${row('৪। তথ্যদাতার নাম:', ud.informantName)}
${row('বয়স:', ud.informantAge)} ${row('লিঙ্গ:', ud.informantSex)}
${row('ঠিকানা:', ud.informantAddress)}
${row('৫। মৃতদেহ শনাক্তকারীর নাম:', ud.identifiedByName)}
${row('বয়স:', ud.identifiedByAge)} ${row('লিঙ্গ:', ud.identifiedBySex)}
${row('সম্পর্ক (যদি থাকে):', ud.identifiedByRelation)}
${row('ঠিকানা:', ud.identifiedByAddress)}
${row('৬। মৃত ব্যক্তির নাম:', ud.deceasedName)}
${row('লিঙ্গ:', ud.deceasedSex)} ${row('আনুমানিক বয়স:', ud.deceasedAge)}
${row('ঠিকানা:', ud.deceasedAddress)}
${row('৭। মৃতদেহের অবস্থান (পোস্টমর্টেম স্টেইনিংসহ):', ud.bodyPosition)}
${row('৮। মৃতদেহের গঠন:', ud.build)} ${row('উচ্চতা:', ud.height)}
${row('রিগর মর্টিস:', ud.rigorMortis)} ${row('গায়ের রং:', ud.complexion)}
${row('বিকৃতি (যদি থাকে):', ud.deformities)} ${row('ধর্ম/জাতি/সম্প্রদায়:', ud.religionRaceCommunity)}
${row('৯। শনাক্তকরণ চিহ্ন—দাঁত:', ud.teeth)} ${row('চোখ:', ud.eyes)} ${row('ত্বকের বিশেষ চিহ্ন:', ud.laceDerma)}
${row('তিল:', ud.mole)} ${row('উল্কি:', ud.tattoo)}
${row('পোশাক/পরিধেয় বস্ত্র:', ud.dress)}
${row('অন্যান্য বৈশিষ্ট্য:', ud.otherFeatures)}
<p>১০। মৃতদেহে পাওয়া বাহ্যিক আঘাতের বিবরণ (প্রয়োজনে পৃথক পাতা সংযুক্ত করুন)।</p>
${row('(ক) মাথা:', ud.injuryHead)} ${row('(খ) মুখ:', ud.injuryFace)} ${row('(গ) ঘাড়:', ud.injuryNeck)} ${row('(ঘ) বুক:', ud.injuryChest)}
${row('(ঙ) পেট:', ud.injuryStomach)} ${row('(চ) কাঁধ:', ud.injuryShoulder)} ${row('(ছ) ডান হাত:', ud.injuryRightHand)}
${row('(জ) বাঁ হাত:', ud.injuryLeftHand)} ${row('(ঝ) ডান পা:', ud.injuryRightLeg)} ${row('(ঞ) বাঁ পা:', ud.injuryLeftLeg)}
${row('(ট) গোপনাঙ্গ:', ud.injuryPrivateParts)} ${row('(ঠ) পিঠ:', ud.injuryBack)} ${row('(ড) অন্যান্য আঘাত:', ud.injuryOther)}
${row('১১(ক)। নাসারন্ধ্র:', ud.nostrils)} ${row('(খ) কান/চোখ:', ud.earsEyes)} ${row('(গ) মুখ:', ud.mouth)}
${row('(ঘ) পুরুষাঙ্গ/যোনি:', ud.penisVagina)} ${row('(ঙ) মলদ্বার:', ud.anus)}
${row('১২। ব্যবহৃত অস্ত্রের প্রকৃতি ও আঘাত সৃষ্টির সম্ভাব্য পদ্ধতি সম্পর্কে মতামত:', ud.weaponOpinion)}
${row('১৩। ফাঁসি/শ্বাসরোধের ক্ষেত্রে গলার দাগ, দড়ি ও গিঁটের বিবরণ:', ud.ligatureDescription)}
${row('১৪। বহিরাগত পদার্থ:', ud.foreignMaterial)}
${row('১৫। ঘটনাস্থলের বিবরণ:', ud.poDescription)}
${row('১৬। ঘটনাস্থলে পাওয়া অস্ত্র, অলংকার ও অন্যান্য সামগ্রীর বিবরণ:', ud.articlesAtPo)}
${row('১৭। মৃত্যুর সম্ভাব্য কারণ সম্পর্কে মতামত:', ud.probableCauseOfDeath)}
${row('১৮। মন্তব্য:', ud.remarks)}
${row('১৯। সাক্ষী (১)-এর নাম/ঠিকানা:', ud.witness1NameAddress)}
${row('সাক্ষী (২)-এর নাম/ঠিকানা:', ud.witness2NameAddress)}
<p>সংক্ষিপ্ত ঘটনা (প্রয়োজনে পৃথক পাতা সংযুক্ত করুন)</p>
<p>${e(ud.briefFacts)}</p>
<div class="right" style="margin-top:40px">তদন্তকারী অফিসারের স্বাক্ষর<br/><br/>নাম: ${e(officer.name)}<br/>পদমর্যাদা: ${e(officer.rank)}</div>
''');
    return _docBytes(html);
  }
}
